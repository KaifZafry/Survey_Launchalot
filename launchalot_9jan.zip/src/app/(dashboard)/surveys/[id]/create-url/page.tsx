export default function CreateUrlPage() {
  return (
    <section className="space-y-2">
      <h1 className="text-2xl font-semibold">Create URL</h1>
      <div className="card">This is a placeholder. Hook this to your backend URL generator later.</div>
    </section>
  );
}
