export default function SignInPage() {
  return (
    <main className="min-h-screen grid place-items-center">
      <div className="card max-w-sm">
        <h1 className="text-xl font-semibold mb-4">Sign in</h1>
        <p>This is a placeholder. Protect routes later with real auth.</p>
      </div>
    </main>
  );
}
