export default function Loading() {
  return (
    <div className="mx-auto max-w-3xl p-6">
      <p className="text-gray-500">Loading survey…</p>
    </div>
  );
}
