const API = process.env.NEXT_PUBLIC_API_URL;

export async function getUIConfig(page: string) {
  const res = await fetch(`${API}/api/ui-config/${page}`, {
    cache: "no-store"
  });
  return res.json();
}

export async function updateUIConfig(page: string, config: any) {
  const res = await fetch(`${API}/ui-config/${page}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ config })
  });

  if (!res.ok) {
    throw new Error("Update failed");
  }

  return res.json();
}
