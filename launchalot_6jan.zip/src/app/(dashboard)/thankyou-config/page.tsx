import ThankYouConfigForm from "./ThankyouConfigForm";
import { getThankYouConfig } from "@/lib/getThankyouConfig";

export default async function AdminThankYouPage() {
  const page = "thank-you";
  const data = await getThankYouConfig(page);

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">
        Thank You Page Config
      </h1>

      <ThankYouConfigForm page={page}  />
    </div>
  );
}
