import { getUIConfig } from "@/lib/getUIConfig";
import UIConfigForm from "./UIConfigForm";

export default async function AdminUIConfigPage() {
  const page = "survey"; // later dropdown se dynamic
  const config = await getUIConfig(page);

  return (
    <div className="p-2 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-2">UI Config – {page}</h1>
      <UIConfigForm page={page} initialConfig={config} />
    </div>
  );
}
