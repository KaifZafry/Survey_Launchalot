export interface ThankYouConfig {
  page: string;
  image: string;     // base64 or url
  heading: string;
  text: string;
}
